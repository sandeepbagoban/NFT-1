self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8dc16bfb64dcf51f28089e9e572a8c91",
    "url": "./index.html"
  },
  {
    "revision": "92bf88d6da488401cf77",
    "url": "./static/css/main.275dfce9.chunk.css"
  },
  {
    "revision": "d9a7e319c39ea6070e9c",
    "url": "./static/js/2.4db09464.chunk.js"
  },
  {
    "revision": "851355396ab1a7f9db452be97ab5e55b",
    "url": "./static/js/2.4db09464.chunk.js.LICENSE.txt"
  },
  {
    "revision": "92bf88d6da488401cf77",
    "url": "./static/js/main.0a73c991.chunk.js"
  },
  {
    "revision": "8e3c5d76060dde60e965",
    "url": "./static/js/runtime-main.e6fef8c9.js"
  }
]);